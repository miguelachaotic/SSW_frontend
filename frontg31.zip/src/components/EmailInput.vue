<script setup>

</script>

<template>
  <div class="inner_login_container">
    <label>
      Email: <input type="text" placeholder="peter@example.com">
    </label>
  </div>
</template>

<style scoped>

</style>