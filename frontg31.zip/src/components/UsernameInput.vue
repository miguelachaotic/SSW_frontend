<script setup>

</script>

<template>
  <div class="inner_login_container">
    <label>
      Username: <input type="text" placeholder="Enter your username">
    </label>
  </div>
</template>

<style scoped>

</style>