<script setup>

</script>

<template>
  <div class="inner_login_container">
    <label>
      Password: <input type="password" placeholder="************">
    </label>
  </div>
</template>

<style scoped>

</style>