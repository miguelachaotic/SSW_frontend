<script setup>

</script>

<template>
  <div class="inner_login_container">
    <label>
      Name: <input type="text" placeholder="Enter your name">
    </label>
  </div>
</template>

<style scoped>

</style>